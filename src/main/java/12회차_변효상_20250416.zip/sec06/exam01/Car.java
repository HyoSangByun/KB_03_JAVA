package main.java.ch06.sec06.exam01;

public class Car {
        //필드 선언
        String model;
        boolean start;
        int speed;

        //다음과 같이 Car 클래스를 정의한 경우, 각 멤버 변수가 가지는 기본값은 무엇인가?
        //    model : null
        //    start : false (0)
        //    speed : 0
}
